'use client'

import { useEffect, useRef } from 'react'

type Brasa = { x: number; y: number; r: number; vy: number; vx: number; fase: number; a: number; dorada: boolean }

function rgb(hex: string): [number, number, number] {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex.trim())
  if (!m) return [255, 90, 31]
  const n = parseInt(m[1], 16)
  return [(n >> 16) & 255, (n >> 8) & 255, n & 255]
}

export default function Particulas({ color = '#ff5a1f' }: { color?: string }) {
  const ref = useRef<HTMLCanvasElement>(null)

  useEffect(() => {
    const canvas = ref.current
    const ctx = canvas?.getContext('2d')
    if (!canvas || !ctx) return

    const reducir = window.matchMedia('(prefers-reduced-motion: reduce)').matches
    const dpr = Math.min(window.devicePixelRatio || 1, 2)
    const principal = rgb(color)
    const dorado: [number, number, number] = [255, 197, 49]
    let w = 0
    let h = 0
    let raf = 0
    let brasas: Brasa[] = []

    const nueva = (inicial: boolean): Brasa => ({
      x: Math.random() * w,
      y: inicial ? Math.random() * h : h + 12,
      r: 1 + Math.random() * 2.6,
      vy: 0.25 + Math.random() * 0.7,
      vx: (Math.random() - 0.5) * 0.3,
      fase: Math.random() * Math.PI * 2,
      a: 0.3 + Math.random() * 0.55,
      dorada: Math.random() < 0.35,
    })

    function ajustar() {
      w = window.innerWidth
      h = window.innerHeight
      canvas!.width = w * dpr
      canvas!.height = h * dpr
      canvas!.style.width = `${w}px`
      canvas!.style.height = `${h}px`
      ctx!.setTransform(dpr, 0, 0, dpr, 0, 0)
      const n = Math.round(Math.min(90, Math.max(30, (w * h) / 18000)))
      brasas = Array.from({ length: n }, () => nueva(true))
    }

    function pintar(t: number) {
      ctx!.clearRect(0, 0, w, h)
      ctx!.globalCompositeOperation = 'lighter'
      for (const b of brasas) {
        if (!reducir) {
          b.y -= b.vy
          b.x += b.vx + Math.sin(t / 1500 + b.fase) * 0.25
          if (b.y < -12 || b.x < -12 || b.x > w + 12) Object.assign(b, nueva(false))
        }
        const [r, g, bl] = b.dorada ? dorado : principal
        const alpha = b.a * Math.min(1, Math.max(0, b.y / (h * 0.45)))
        ctx!.fillStyle = `rgba(${r},${g},${bl},${alpha * 0.18})`
        ctx!.beginPath()
        ctx!.arc(b.x, b.y, b.r * 4, 0, Math.PI * 2)
        ctx!.fill()
        ctx!.fillStyle = `rgba(${r},${g},${bl},${alpha})`
        ctx!.beginPath()
        ctx!.arc(b.x, b.y, b.r, 0, Math.PI * 2)
        ctx!.fill()
      }
      if (!reducir) raf = requestAnimationFrame(pintar)
    }

    ajustar()
    raf = requestAnimationFrame(pintar)
    window.addEventListener('resize', ajustar)
    return () => {
      cancelAnimationFrame(raf)
      window.removeEventListener('resize', ajustar)
    }
  }, [color])

  return <canvas ref={ref} aria-hidden className="pointer-events-none fixed inset-0 -z-10" />
}
